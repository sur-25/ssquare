import { Component, OnInit, OnDestroy } from "@angular/core";
import { AppService } from "../app.service";
import { Product } from "../product.model";
import {Subscription} from "rxjs"

@Component({
  selector: "app-inventory",
  templateUrl: "./inventory.component.html",
  styleUrls: ["./inventory.component.css"]
})
export class InventoryComponent implements OnInit ,OnDestroy {
  products: Product[] = [];
  prodSub:Subscription;

  constructor(public appSevice: AppService) {}
  ngOnInit() {
    this.products = this.appSevice.getProduct();
   this.prodSub= this.appSevice.getUpdateProductListner().subscribe((product: Product[]) => {
      this.products = product;
    });

  }
  ngOnDestroy(){
    this.prodSub.unsubscribe();
  }

}
